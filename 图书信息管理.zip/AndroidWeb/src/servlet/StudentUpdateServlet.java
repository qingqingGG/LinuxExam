package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.StudentDao;
import dao.UserDao;
import entity.Student;
import entity.User;

public class StudentUpdateServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		System.out.println("-----------------");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("UTF-8");
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		int age =  Integer.parseInt(request.getParameter("age"));
		String address =  request.getParameter("address");
		
		
		Student student = new Student();

		student.setId(id);
		student.setName(name);
		student.setAge(age);
		student.setAddress(address);

		System.out.println(student);
		
        String msg = "";
        StudentDao studentDao = new StudentDao();
            
        boolean flag = studentDao.update(student);
        
        if(flag){
            msg = "�ɹ�";
        }else{
        	msg = "ʧ��";
        }
	   
        PrintWriter out = response.getWriter();
		out.println(msg);
		out.flush();
		out.close();

		
	}


}
