package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import dao.StudentDao;
import dao.UserDao;
import entity.Student;

public class StudentServlet extends HttpServlet {
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//��ȡ��������
		
		
		String name=request.getParameter("name");
		
		
		//����dao��
		StudentDao studentDAO=new StudentDao();
		
		ArrayList<Student> stuList=studentDAO.getStuByName(name);
		
		
		response.setContentType("application/x-json");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		
		
		
		JSONArray jsonArray = JSONArray.fromObject(stuList); 
		out.print(jsonArray);
		System.out.println(jsonArray);
		
		out.flush();
		out.close();
		
	}

	

}
