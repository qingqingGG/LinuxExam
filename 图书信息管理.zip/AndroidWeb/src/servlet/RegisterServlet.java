package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;

import entity.User;

public class RegisterServlet extends HttpServlet {

	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		System.out.println("-----------------");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("UTF-8");
		String name = request.getParameter("name");
		String username = request.getParameter("username");
		String password =  request.getParameter("password");
		String phone =  request.getParameter("phone");
		int age =  Integer.parseInt(request.getParameter("age"));
		
		
		User user = new User();

        user.setName(name);
        user.setUsername(username);
        user.setPassword(password);
        user.setAge(age);
        user.setPhone(phone);

        String msg = "";
        UserDao userDao = null;
        User uu = null;
        	userDao = new UserDao();
        	 uu = userDao.findUser(user.getName());
        	 
       
        boolean flag = false;
        if(uu == null){
        	flag = userDao.register(user);
            
        }

        
        if(flag){
            msg = "�ɹ�";
        }else{
        	msg = "ʧ��";
        }
	     if(uu != null)
	   	{
	   		 
	   		 msg = "�Ѵ���";
	   	 }
	
        PrintWriter out = response.getWriter();
		out.println(msg);
		out.flush();
		out.close();

		
	}


}
