package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.Student;
import entity.User;

public class StudentDao {
	
	
	
	public ArrayList<Student> getStuByName(String name)
	{
		
		ArrayList<Student> stuList=new ArrayList<Student>();
		
		
		
		String sql="select * from student where name like '%"+name+"%'";

        Connection con=JDBCUtils.getConn();


        try {
            PreparedStatement pst=con.prepareStatement(sql);

            ResultSet rs=pst.executeQuery();
            
            while(rs.next())
            {
            	Student stu=new Student();
            	
            	stu.setId(rs.getInt(1));
            	stu.setName(rs.getString(2));
            	stu.setAge(rs.getInt(3));
            	stu.setAddress(rs.getString(4));
            	
            	stuList.add(stu);
            }


        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
        	JDBCUtils.close(con);
        }
        
        return stuList;
	}
	
	 public boolean update(Student stu){

		 String sql="update student set name=?,age=?,address=? where id=?";
	        Connection  con = JDBCUtils.getConn();

	        try {
	            PreparedStatement pst=con.prepareStatement(sql);

	            pst.setString(1,stu.getName());
	            pst.setInt(2,stu.getAge());
	            pst.setString(3,stu.getAddress() );
	            pst.setInt(4,stu.getId()   );

	            int value = pst.executeUpdate();

	            if(value>0){
	                return true;
	            }


	        } catch (SQLException throwables) {
	            throwables.printStackTrace();
	        }finally {
	            JDBCUtils.close(con);
	        }
	        return false;
	    }
	

}
