package com.example.application01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.application01.utils.PostUtil;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class StudentUpdate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_update);

        Intent intent = getIntent();

        String id =    intent.getStringExtra("id");
        String name =  intent.getStringExtra("name");
        String age = intent.getStringExtra("age");
        String address = intent.getStringExtra("address");


        TextView idtv = findViewById(R.id.id);
        EditText nameet = findViewById(R.id.name);
        EditText ageet = findViewById(R.id.age);
        EditText addresset = findViewById(R.id.address);

        idtv.setText(id);
        nameet.setText(name);
        ageet.setText(age);
        addresset.setText(address);

    }


    public void updatestudent(View view){


        TextView idtv = findViewById(R.id.id);
        EditText nameet = findViewById(R.id.name);
        EditText ageet = findViewById(R.id.age);
        EditText addresset = findViewById(R.id.address);

        String id =  idtv.getText().toString();
        String name =   nameet.getText().toString();
        String age =  ageet.getText().toString();
        String address = addresset.getText().toString();


        new Thread(){
            @Override
            public void run() {

                String data="";
                try {
                    data = "&id="+ URLEncoder.encode(id, "UTF-8")+
                            "&name="+ URLEncoder.encode(name, "UTF-8")+
                            "&age="+ URLEncoder.encode(age, "UTF-8")+
                            "&address="+ URLEncoder.encode(address, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }

                String request = PostUtil.Post("studentUpdateServlet",data);

                int msg = 0;
                if(request.equals("成功")){
                    msg = 1;
                }


                hand.sendEmptyMessage(msg);

            }
        }.start();


    }
    Handler hand=new Handler(){
        @Override
        public void handleMessage(Message msg) {

            if(msg.what == 1)
            {
                startActivity(new Intent( getApplicationContext(),  Student_List.class ) );
                //startActivity(new Intent( getApplicationContext(),  StuInfoActivity.class ) );
            }
            else
            {
                Toast.makeText(getApplicationContext(),"更新失败",Toast.LENGTH_LONG).show();
            }
        }

    };
}