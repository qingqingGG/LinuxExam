package com.example.application01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.application01.entity.Student;
import com.example.application01.utils.PostUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

public class Student_List extends AppCompatActivity {

    EditText editTextname = null;

    ArrayList<Student> studatalist = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student__list);
        editTextname = findViewById(R.id.stuname);

    }


    public void findALLStudent(View view){


        new Thread() {
            public void run() {

                if(studatalist != null){
                    studatalist.clear();
                }


                String data="";
                try {
                    data = "name="+ URLEncoder.encode(editTextname.getText().toString(), "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }

                String stuJson= PostUtil.Post("studentServlet",data);

                System.out.println(stuJson);
                try {

                    JSONArray jsonArray = new JSONArray(stuJson);

                    for(int i = 0;i < jsonArray.length();i++){

                        JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                        Student student = new Student();
                        student.setId(jsonObject.getInt("id"));
                        student.setName(jsonObject.getString("name"));
                        student.setAge(jsonObject.getInt("age"));
                        student.setAddress(jsonObject.getString("address"));
                        studatalist.add(student);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                /*
                 */
                hand.sendEmptyMessage(1);

            }

        }.start();



    }
    Handler hand=new Handler(){
        @Override
        public void handleMessage(Message msg) {

            if(msg.what == 1)
            {
                ListView stuList = (ListView) findViewById(R.id.stulist);

                final LayoutInflater inflater = LayoutInflater.from(getApplicationContext());
                View headView = inflater.inflate(R.layout.list_header, null);

                if(stuList.getHeaderViewsCount()==0)
                {
                    stuList.addHeaderView(headView);
                }

                StudentAdapter adapter = new StudentAdapter( studatalist, Student_List.this);
                stuList.setAdapter(adapter);
                //startActivity(new Intent( getApplicationContext(),  StuInfoActivity.class ) );
            }
            else
            {
                Toast.makeText(getApplicationContext(),"查询错误",Toast.LENGTH_LONG).show();
            }
        }

    };

    public void update(View view){

        LinearLayout linearLayout =  (LinearLayout)(view.getParent().getParent());

        TextView idEd = linearLayout.findViewById(R.id.id);
        TextView nameEd =  linearLayout.findViewById(R.id.name);
        TextView ageEd = linearLayout.findViewById(R.id.age);
        TextView addressEd = linearLayout.findViewById(R.id.address);

        Intent intent=new Intent();
        intent.putExtra("id", idEd.getText().toString());
        intent.putExtra("name", nameEd.getText().toString());
        intent.putExtra("age", ageEd.getText().toString());
        intent.putExtra("address", addressEd.getText().toString());
        intent.setClass(this, StudentUpdate.class);
        startActivity(intent );


        Toast.makeText(getApplicationContext(),"修改",Toast.LENGTH_LONG).show();

    }

    public void delete(View view){

        Toast.makeText(getApplicationContext(),"删除",Toast.LENGTH_LONG).show();

    }

}