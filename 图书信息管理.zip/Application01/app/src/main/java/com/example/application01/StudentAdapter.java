package com.example.application01;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.application01.entity.Student;

import java.util.ArrayList;

public class StudentAdapter extends BaseAdapter {

    private ArrayList<Student> sData;
    private Context mContext;

    public StudentAdapter(ArrayList<Student> sData, Context mContext) {
        this.sData = sData;
        this.mContext = mContext;
    }

    @Override
    public int getCount() {
        return sData.size();
    }
    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        convertView = LayoutInflater.from(mContext).inflate(R.layout.student_list,null);


        TextView txt_id = (TextView) convertView.findViewById(R.id.id);
        TextView txt_name = (TextView) convertView.findViewById(R.id.name);
        TextView txt_age = (TextView) convertView.findViewById(R.id.age);
        TextView txt_address = (TextView) convertView.findViewById(R.id.address);


        txt_id.setText(sData.get(position).getId()+"");
        txt_name.setText(sData.get(position).getName());
        txt_age.setText(sData.get(position).getAge()+"");
        txt_address.setText(sData.get(position).getAddress());

        return convertView;
    }




}
