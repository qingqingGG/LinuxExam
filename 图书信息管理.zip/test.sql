/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50562
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50562
File Encoding         : 65001

Date: 2021-05-24 17:55:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `student`
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', 'andy', '21', '北京');
INSERT INTO `student` VALUES ('2', '张三', '36', '上海121');
INSERT INTO `student` VALUES ('3', 'asdc', '34', '大连');
INSERT INTO `student` VALUES ('4', '张三', '20', '北京');

-- ----------------------------
-- Table structure for `users`
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `age` int(255) NOT NULL,
  `phone` longblob NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('2', '123', 'HBV环保局', '123', '33', 0x3133333333333333333333);
INSERT INTO `users` VALUES ('3', '1233', '反复的', '1233', '12', 0x3132333333333333333333);
INSERT INTO `users` VALUES ('4', '1244', '第三代', '1244', '12', 0x3133333333333333333333);
INSERT INTO `users` VALUES ('5', '1255', 'SAS', '1255', '33', 0x3133333333333333333333);
INSERT INTO `users` VALUES ('6', '122', '但是ADS', '122', '12', 0x3132323232323232323232);
INSERT INTO `users` VALUES ('7', 'admin123', 'admin', '123', '45', 0x3132323232323232323232);
INSERT INTO `users` VALUES ('8', 'admin123', 'admin', '123', '45', 0x3132323232323232323232);
INSERT INTO `users` VALUES ('9', 'admin123', 'admin', '123', '45', 0x3132323232323232323232);
INSERT INTO `users` VALUES ('10', 'admin1232', 'admin', '123', '45', 0x3132323232323232323232);
INSERT INTO `users` VALUES ('11', 'admin222', '222', '2222', '222', 0x3232323232323232323232);
INSERT INTO `users` VALUES ('12', 'admin123', '123', '1212', '22', 0x32313231323232323232);
INSERT INTO `users` VALUES ('13', 'admin', 'admin', '2121', '33', 0x3333333333333333333333);
INSERT INTO `users` VALUES ('14', '123121212', '12321212', '123', '12', 0x3132333333333333333333);
